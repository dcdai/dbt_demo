# AWS KMS Encryption Service

This is a Spring Boot application that provides an API to encrypt data using AWS KMS and return the encrypted data in Base64 format.

## Prerequisites

- Java 17 or higher
- Maven 3.6 or higher
- AWS credentials configured (via AWS CLI, environment variables, or IAM roles)

## Setup

1. Clone or download this project
2. Ensure AWS credentials are configured:
   - Option 1: Configure AWS CLI (`aws configure`)
   - Option 2: Set environment variables (`AWS_ACCESS_KEY_ID`, `AWS_SECRET_ACCESS_KEY`, `AWS_REGION`)
   - Option 3: If running on EC2, ensure an IAM role is attached with KMS permissions

## Building the Project

```bash
mvn clean install
```

## Running the Application

```bash
mvn spring-boot:run
```

The API will be available at `http://localhost:8080`

## API Endpoints

### Encrypt Data
- **Endpoint**: `POST /api/kms/encrypt`
- **Description**: Encrypts the provided data using AWS KMS
- **Request Body**:
```json
{
  "data": "string to encrypt",
  "keyId": "KMS key ID, ARN, or alias"
}
```
- **Response**:
```json
{
  "encryptedData": "Base64 encoded encrypted data",
  "message": "Data encrypted successfully"
}
```

### Decrypt Data (for reference)
- **Endpoint**: `POST /api/kms/decrypt`
- **Description**: Decrypts the provided encrypted data using AWS KMS
- **Request Body**:
```json
{
  "encryptedData": "Base64 encoded encrypted data",
  "keyId": "KMS key ID, ARN, or alias"
}
```
- **Response**:
```json
{
  "decryptedData": "Decrypted string data",
  "message": "Data decrypted successfully"
}
```

### Sign Data with Digital Signature
- **Endpoint**: `POST /api/kms/sign`
- **Description**: Signs the provided data using AWS KMS with a private key, and returns the original data, public key, and signature
- **Request Body**:
```json
{
  "data": "string to sign",
  "keyId": "KMS key ID or ARN (must be an asymmetric signing key)",
  "signingAlgorithm": "Optional signing algorithm (e.g., RSASSA_PKCS1_V1_5_SHA_256)"
}
```
- **Response**:
```json
{
  "originalData": "Original data that was signed",
  "publicKey": "Base64 encoded public key",
  "signature": "Base64 encoded signature",
  "message": "Data signed successfully"
}
```

### Verify Digital Signature
- **Endpoint**: `POST /api/kms/verify-signature`
- **Description**: Verifies a signature using the provided public key by checking if the signature matches the original data
- **Request Body**:
```json
{
  "originalData": "Original data that was signed",
  "signature": "Base64 encoded signature to verify",
  "publicKey": "Base64 encoded public key",
  "signingAlgorithm": "Optional signing algorithm (e.g., RSASSA_PKCS1_V1_5_SHA_256)"
}
```
- **Response**:
```json
{
  "isValid": true,
  "message": "Signature is valid"
}
```

## Example Usage

### Encrypting Data

```bash
curl -X POST http://localhost:8080/api/kms/encrypt \
  -H "Content-Type: application/json" \
  -d '{
    "data": "Hello, World!",
    "keyId": "your-kms-key-id-or-arn-or-alias"
  }'
```

### Decrypting Data

```bash
curl -X POST http://localhost:8080/api/kms/decrypt \
  -H "Content-Type: application/json" \
  -d '{
    "encryptedData": "your-base64-encoded-encrypted-data",
    "keyId": "your-kms-key-id-or-arn-or-alias"
  }'
```

### Signing Data

```bash
curl -X POST http://localhost:8080/api/kms/sign \
  -H "Content-Type: application/json" \
  -d '{
    "data": "Data to sign",
    "keyId": "your-kms-asymmetric-signing-key-id-or-arn-or-alias",
    "signingAlgorithm": "RSASSA_PKCS1_V1_5_SHA_256"
  }'
```

### Verifying Signature

```bash
curl -X POST http://localhost:8080/api/kms/verify-signature \
  -H "Content-Type: application/json" \
  -d '{
    "originalData": "Original data that was signed",
    "signature": "base64-encoded-signature-from-sign-operation",
    "publicKey": "base64-encoded-public-key-from-sign-operation",
    "signingAlgorithm": "RSASSA_PKCS1_V1_5_SHA_256"
  }'
```

## AWS KMS Permissions

Ensure your AWS credentials have the following permissions for the KMS key:

For encryption/decryption:
- `kms:Encrypt`
- `kms:Decrypt`

For digital signing:
- `kms:Sign`
- `kms:GetPublicKey`

Note: For digital signing, you need an asymmetric KMS key with signing capabilities.

For signature verification with this API, no KMS permissions are required as verification is done locally with the provided public key.

## Configuration

The application uses the default AWS credentials provider chain. You can customize the region in `application.yml`.

## Dependencies

- Spring Boot Web Starter
- AWS SDK for KMS
- Spring Boot Validation Starter