package com.example.kms.controller;

import com.example.kms.service.KmsSigningService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@RestController
@RequestMapping("/api/kms")
public class KmsSigningController {

    @Autowired
    private KmsSigningService kmsSigningService;

    /**
     * API endpoint to sign data using AWS KMS
     * 
     * @param request Request object containing data to sign and KMS key ID
     * @return ResponseEntity with original data, public key, and signature
     */
    @PostMapping("/sign")
    public ResponseEntity<SigningResponse> signData(@RequestBody @NotNull SigningRequest request) {
        try {
            // Get the public key from KMS
            String publicKey = kmsSigningService.getPublicKey(request.getKeyId());
            
            // Sign the data using the private key in KMS
            String signature = kmsSigningService.signData(
                request.getData(), 
                request.getKeyId(), 
                request.getSigningAlgorithm() != null ? request.getSigningAlgorithm() : "RSASSA_PKCS1_V1_5_SHA_256"
            );
            
            SigningResponse response = new SigningResponse(
                request.getData(), 
                publicKey, 
                signature, 
                "Data signed successfully"
            );
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            SigningResponse errorResponse = new SigningResponse(
                null, 
                null, 
                null, 
                "Signing failed: " + e.getMessage()
            );
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    // Request and Response DTOs for signing
    public static class SigningRequest {
        @NotBlank(message = "Data to sign cannot be blank")
        private String data;
        
        @NotBlank(message = "KMS Key ID cannot be blank")
        private String keyId;
        
        private String signingAlgorithm; // Optional, defaults to RSASSA_PKCS1_V1_5_SHA_256

        // Constructors
        public SigningRequest() {}

        public SigningRequest(String data, String keyId, String signingAlgorithm) {
            this.data = data;
            this.keyId = keyId;
            this.signingAlgorithm = signingAlgorithm;
        }

        // Getters and Setters
        public String getData() {
            return data;
        }

        public void setData(String data) {
            this.data = data;
        }

        public String getKeyId() {
            return keyId;
        }

        public void setKeyId(String keyId) {
            this.keyId = keyId;
        }

        public String getSigningAlgorithm() {
            return signingAlgorithm;
        }

        public void setSigningAlgorithm(String signingAlgorithm) {
            this.signingAlgorithm = signingAlgorithm;
        }
    }

    public static class SigningResponse {
        private String originalData;
        private String publicKey;
        private String signature;
        private String message;

        public SigningResponse(String originalData, String publicKey, String signature, String message) {
            this.originalData = originalData;
            this.publicKey = publicKey;
            this.signature = signature;
            this.message = message;
        }

        // Getters and Setters
        public String getOriginalData() {
            return originalData;
        }

        public void setOriginalData(String originalData) {
            this.originalData = originalData;
        }

        public String getPublicKey() {
            return publicKey;
        }

        public void setPublicKey(String publicKey) {
            this.publicKey = publicKey;
        }

        public String getSignature() {
            return signature;
        }

        public void setSignature(String signature) {
            this.signature = signature;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}