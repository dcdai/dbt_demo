package com.example.kms.controller;

import com.example.kms.service.KmsEncryptionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@RestController
@RequestMapping("/api/kms")
public class KmsEncryptionController {

    @Autowired
    private KmsEncryptionService kmsEncryptionService;

    /**
     * API endpoint to encrypt data using AWS KMS
     * 
     * @param request Request object containing data to encrypt and KMS key ID
     * @return ResponseEntity with Base64 encoded encrypted data
     */
    @PostMapping("/encrypt")
    public ResponseEntity<EncryptionResponse> encryptData(@RequestBody @NotNull EncryptionRequest request) {
        try {
            String encryptedData = kmsEncryptionService.encryptData(request.getData(), request.getKeyId());
            EncryptionResponse response = new EncryptionResponse(encryptedData, "Data encrypted successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            EncryptionResponse errorResponse = new EncryptionResponse(null, "Encryption failed: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    /**
     * API endpoint to decrypt data using AWS KMS (for reference)
     * 
     * @param request Request object containing encrypted data and KMS key ID
     * @return ResponseEntity with decrypted data
     */
    @PostMapping("/decrypt")
    public ResponseEntity<DecryptionResponse> decryptData(@RequestBody @NotNull DecryptionRequest request) {
        try {
            String decryptedData = kmsEncryptionService.decryptData(request.getEncryptedData(), request.getKeyId());
            DecryptionResponse response = new DecryptionResponse(decryptedData, "Data decrypted successfully");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            DecryptionResponse errorResponse = new DecryptionResponse(null, "Decryption failed: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    // Request and Response DTOs
    public static class EncryptionRequest {
        @NotBlank(message = "Data to encrypt cannot be blank")
        private String data;
        
        @NotBlank(message = "KMS Key ID cannot be blank")
        private String keyId;  // Can be key ID, key ARN, or key alias

        // Constructors
        public EncryptionRequest() {}

        public EncryptionRequest(String data, String keyId) {
            this.data = data;
            this.keyId = keyId;
        }

        // Getters and Setters
        public String getData() {
            return data;
        }

        public void setData(String data) {
            this.data = data;
        }

        public String getKeyId() {
            return keyId;
        }

        public void setKeyId(String keyId) {
            this.keyId = keyId;
        }
    }

    public static class EncryptionResponse {
        private String encryptedData;
        private String message;

        public EncryptionResponse(String encryptedData, String message) {
            this.encryptedData = encryptedData;
            this.message = message;
        }

        // Getters and Setters
        public String getEncryptedData() {
            return encryptedData;
        }

        public void setEncryptedData(String encryptedData) {
            this.encryptedData = encryptedData;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }

    public static class DecryptionRequest {
        @NotBlank(message = "Encrypted data cannot be blank")
        private String encryptedData;
        
        @NotBlank(message = "KMS Key ID cannot be blank")
        private String keyId;  // Can be key ID, key ARN, or key alias

        // Constructors
        public DecryptionRequest() {}

        public DecryptionRequest(String encryptedData, String keyId) {
            this.encryptedData = encryptedData;
            this.keyId = keyId;
        }

        // Getters and Setters
        public String getEncryptedData() {
            return encryptedData;
        }

        public void setEncryptedData(String encryptedData) {
            this.encryptedData = encryptedData;
        }

        public String getKeyId() {
            return keyId;
        }

        public void setKeyId(String keyId) {
            this.keyId = keyId;
        }
    }

    public static class DecryptionResponse {
        private String decryptedData;
        private String message;

        public DecryptionResponse(String decryptedData, String message) {
            this.decryptedData = decryptedData;
            this.message = message;
        }

        // Getters and Setters
        public String getDecryptedData() {
            return decryptedData;
        }

        public void setDecryptedData(String decryptedData) {
            this.decryptedData = decryptedData;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}