package com.example.kms.controller;

import com.example.kms.service.KmsSignatureVerificationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

@RestController
@RequestMapping("/api/kms")
public class KmsSignatureVerificationController {

    @Autowired
    private KmsSignatureVerificationService kmsSignatureVerificationService;

    /**
     * API endpoint to verify a signature using the provided public key
     * 
     * @param request Request object containing original data, signature, and public key
     * @return ResponseEntity with verification result
     */
    @PostMapping("/verify-signature")
    public ResponseEntity<SignatureVerificationResponse> verifySignature(@RequestBody @NotNull SignatureVerificationRequest request) {
        try {
            boolean isValid = kmsSignatureVerificationService.verifySignatureWithPublicKey(
                request.getOriginalData(),
                request.getSignature(),
                request.getPublicKey(),
                request.getSigningAlgorithm() != null ? request.getSigningAlgorithm() : "RSASSA_PKCS1_V1_5_SHA_256"
            );
            
            String message = isValid ? "Signature is valid" : "Signature is invalid";
            SignatureVerificationResponse response = new SignatureVerificationResponse(isValid, message);
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            SignatureVerificationResponse errorResponse = new SignatureVerificationResponse(false, "Verification failed: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    // Request and Response DTOs for signature verification
    public static class SignatureVerificationRequest {
        @NotBlank(message = "Original data cannot be blank")
        private String originalData;
        
        @NotBlank(message = "Signature cannot be blank")
        private String signature; // Base64 encoded signature
        
        @NotBlank(message = "Public key cannot be blank")
        private String publicKey; // Base64 encoded public key
        
        private String signingAlgorithm; // Optional, defaults to RSASSA_PKCS1_V1_5_SHA_256

        // Constructors
        public SignatureVerificationRequest() {}

        public SignatureVerificationRequest(String originalData, String signature, String publicKey, String signingAlgorithm) {
            this.originalData = originalData;
            this.signature = signature;
            this.publicKey = publicKey;
            this.signingAlgorithm = signingAlgorithm;
        }

        // Getters and Setters
        public String getOriginalData() {
            return originalData;
        }

        public void setOriginalData(String originalData) {
            this.originalData = originalData;
        }

        public String getSignature() {
            return signature;
        }

        public void setSignature(String signature) {
            this.signature = signature;
        }

        public String getPublicKey() {
            return publicKey;
        }

        public void setPublicKey(String publicKey) {
            this.publicKey = publicKey;
        }

        public String getSigningAlgorithm() {
            return signingAlgorithm;
        }

        public void setSigningAlgorithm(String signingAlgorithm) {
            this.signingAlgorithm = signingAlgorithm;
        }
    }

    public static class SignatureVerificationResponse {
        private boolean isValid;
        private String message;

        public SignatureVerificationResponse(boolean isValid, String message) {
            this.isValid = isValid;
            this.message = message;
        }

        // Getters and Setters
        public boolean isValid() {
            return isValid;
        }

        public void setValid(boolean valid) {
            isValid = valid;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }
    }
}