package com.example.kms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class KmsEncryptionServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(KmsEncryptionServiceApplication.class, args);
    }

}