package com.example.kms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.auth.credentials.DefaultCredentialsProvider;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.kms.KmsClient;

@Configuration
public class AwsKmsConfig {

    @Bean
    public KmsClient kmsClient() {
        return KmsClient.builder()
                .region(Region.AP_EAST_1) // You can change this to your preferred region
                .credentialsProvider(DefaultCredentialsProvider.create())
                .build();
    }
}