package com.example.kms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.kms.KmsClient;
import software.amazon.awssdk.services.kms.model.GetPublicKeyRequest;
import software.amazon.awssdk.services.kms.model.GetPublicKeyResponse;
import software.amazon.awssdk.services.kms.model.SignRequest;
import software.amazon.awssdk.services.kms.model.SigningAlgorithmSpec;
import software.amazon.awssdk.services.kms.model.KmsException;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Service
public class KmsSigningService {

    @Autowired
    private KmsClient kmsClient;

    /**
     * Signs data using AWS KMS with a private key stored in KMS
     * @param data The data to sign
     * @param keyId The KMS key ID or ARN to use for signing (must be an asymmetric signing key)
     * @param signingAlgorithm The signing algorithm to use (e.g., "RSASSA_PKCS1_V1_5_SHA_256")
     * @return Base64 encoded signature
     */
    public String signData(String data, String keyId, String signingAlgorithm) {
        try {
            // Convert the string data to SdkBytes
            SdkBytes dataToSign = SdkBytes.fromUtf8String(data);

            // Determine the signing algorithm enum
            SigningAlgorithmSpec algorithmSpec = getSigningAlgorithmSpec(signingAlgorithm);

            // Create a sign request
            SignRequest signRequest = SignRequest.builder()
                    .keyId(keyId)
                    .message(dataToSign)
                    .signingAlgorithm(algorithmSpec)
                    .build();

            // Call the sign method
            var response = kmsClient.sign(signRequest);

            // Get the signature
            SdkBytes signature = response.signature();

            // Encode the signature to Base64
            byte[] signatureBytes = signature.asByteArray();
            String base64Signature = Base64.getEncoder().encodeToString(signatureBytes);

            return base64Signature;
        } catch (KmsException e) {
            throw new RuntimeException("Error signing data with KMS: " + e.getMessage(), e);
        }
    }

    /**
     * Retrieves the public key associated with the asymmetric key in KMS
     * @param keyId The KMS key ID or ARN
     * @return Base64 encoded public key
     */
    public String getPublicKey(String keyId) {
        try {
            // Create a get public key request
            GetPublicKeyRequest publicKeyRequest = GetPublicKeyRequest.builder()
                    .keyId(keyId)
                    .build();

            // Call the getPublicKey method
            GetPublicKeyResponse response = kmsClient.getPublicKey(publicKeyRequest);

            // Get the public key
            SdkBytes publicKeyBytes = response.publicKey();

            // Encode the public key to Base64
            byte[] publicKey = publicKeyBytes.asByteArray();
            String base64PublicKey = Base64.getEncoder().encodeToString(publicKey);

            return base64PublicKey;
        } catch (KmsException e) {
            throw new RuntimeException("Error retrieving public key from KMS: " + e.getMessage(), e);
        }
    }

    /**
     * Helper method to get the signing algorithm spec from string
     * @param algorithmString The algorithm string
     * @return SigningAlgorithmSpec enum value
     */
    private SigningAlgorithmSpec getSigningAlgorithmSpec(String algorithmString) {
        try {
            return SigningAlgorithmSpec.fromValue(algorithmString);
        } catch (IllegalArgumentException e) {
            // If the algorithm string is invalid, default to RSASSA_PKCS1_V1_5_SHA_256
            return SigningAlgorithmSpec.RSASSA_PKCS1_V1_5_SHA_256;
        }
    }
}