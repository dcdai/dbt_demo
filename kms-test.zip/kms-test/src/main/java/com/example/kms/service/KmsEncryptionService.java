package com.example.kms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.kms.KmsClient;
import software.amazon.awssdk.services.kms.model.DecryptRequest;
import software.amazon.awssdk.services.kms.model.EncryptRequest;
import software.amazon.awssdk.services.kms.model.KmsException;

import java.nio.charset.StandardCharsets;
import java.util.Base64;

@Service
public class KmsEncryptionService {

    @Autowired
    private KmsClient kmsClient;

    /**
     * Encrypts data using AWS KMS
     * @param data The data to encrypt
     * @param keyId The KMS key ID, ARN, or alias to use for encryption
     * @return Base64 encoded encrypted data
     */
    public String encryptData(String data, String keyId) {
        try {
            // Convert the string data to SdkBytes
            SdkBytes plaintext = SdkBytes.fromUtf8String(data);

            // Create an encrypt request
            EncryptRequest encryptRequest = EncryptRequest.builder()
                    .keyId(keyId)  // KMS accepts key ID, ARN, or alias
                    .plaintext(plaintext)
                    .build();

            // Call the encrypt method
            var response = kmsClient.encrypt(encryptRequest);

            // Get the encrypted data
            SdkBytes encryptedData = response.ciphertextBlob();

            // Encode the encrypted data to Base64
            byte[] encryptedBytes = encryptedData.asByteArray();
            String base64EncryptedData = Base64.getEncoder().encodeToString(encryptedBytes);

            return base64EncryptedData;
        } catch (KmsException e) {
            throw new RuntimeException("Error encrypting data with KMS: " + e.getMessage(), e);
        }
    }

    /**
     * Decrypts data using AWS KMS (for reference, if needed)
     * @param encryptedDataBase64 The Base64 encoded encrypted data
     * @param keyId The KMS key ID, ARN, or alias to use for decryption
     * @return Decrypted data as string
     */
    public String decryptData(String encryptedDataBase64, String keyId) {
        try {
            // Decode the Base64 encrypted data
            byte[] encryptedBytes = Base64.getDecoder().decode(encryptedDataBase64);
            SdkBytes encryptedSdkBytes = SdkBytes.fromByteArray(encryptedBytes);

            // Create a decrypt request
            DecryptRequest decryptRequest = DecryptRequest.builder()
                    .keyId(keyId)  // KMS accepts key ID, ARN, or alias
                    .ciphertextBlob(encryptedSdkBytes)
                    .build();

            // Call the decrypt method
            var response = kmsClient.decrypt(decryptRequest);

            // Get the decrypted data
            SdkBytes decryptedData = response.plaintext();
            return decryptedData.asUtf8String();
        } catch (KmsException e) {
            throw new RuntimeException("Error decrypting data with KMS: " + e.getMessage(), e);
        }
    }
}