package com.example.kms.service;

import org.springframework.stereotype.Service;
import software.amazon.awssdk.core.SdkBytes;
import software.amazon.awssdk.services.kms.KmsClient;
import software.amazon.awssdk.services.kms.model.VerifyRequest;
import software.amazon.awssdk.services.kms.model.VerifyResponse;
import software.amazon.awssdk.services.kms.model.SigningAlgorithmSpec;
import software.amazon.awssdk.services.kms.model.KmsException;

import java.security.PublicKey;
import java.security.spec.X509EncodedKeySpec;
import java.security.KeyFactory;
import java.security.Signature;
import java.util.Base64;
import java.nio.charset.StandardCharsets;

@Service
public class KmsSignatureVerificationService {

    private final KmsClient kmsClient;

    public KmsSignatureVerificationService(KmsClient kmsClient) {
        this.kmsClient = kmsClient;
    }

    /**
     * Verifies a signature using AWS KMS
     * 
     * @param originalData The original data that was signed
     * @param signature The signature to verify (Base64 encoded)
     * @param keyId The KMS key ID or ARN used for signing
     * @param signingAlgorithm The signing algorithm used
     * @return Verification result indicating if the signature is valid
     */
    public boolean verifySignatureWithKms(String originalData, String signature, String keyId, String signingAlgorithm) {
        try {
            // Convert the original data to SdkBytes
            SdkBytes dataToVerify = SdkBytes.fromUtf8String(originalData);

            // Decode the signature from Base64
            byte[] signatureBytes = Base64.getDecoder().decode(signature);
            SdkBytes signatureSdkBytes = SdkBytes.fromByteArray(signatureBytes);

            // Determine the signing algorithm spec
            SigningAlgorithmSpec algorithmSpec = getSigningAlgorithmSpec(signingAlgorithm);

            // Create a verify request
            VerifyRequest verifyRequest = VerifyRequest.builder()
                    .keyId(keyId)
                    .message(dataToVerify)
                    .signature(signatureSdkBytes)
                    .signingAlgorithm(algorithmSpec)
                    .build();

            // Call the verify method
            VerifyResponse response = kmsClient.verify(verifyRequest);

            // Return whether the signature is valid
            return response.signatureValid();
        } catch (KmsException e) {
            throw new RuntimeException("Error verifying signature with KMS: " + e.getMessage(), e);
        }
    }

    /**
     * Verifies a signature using the provided public key directly
     * 
     * @param originalData The original data that was signed
     * @param signature The signature to verify (Base64 encoded)
     * @param publicKey The public key to use for verification (Base64 encoded)
     * @param signingAlgorithm The signing algorithm used
     * @return Verification result indicating if the signature is valid
     */
    public boolean verifySignatureWithPublicKey(String originalData, String signature, String publicKey, String signingAlgorithm) {
        try {
            // Decode the public key from Base64
            byte[] keyBytes = Base64.getDecoder().decode(publicKey);
            
            // Create a key specification
            X509EncodedKeySpec spec = new X509EncodedKeySpec(keyBytes);
            
            // Get the key factory for the appropriate algorithm based on the signing algorithm
            String keyAlgorithm = getKeyAlgorithmFromSigningAlgorithm(signingAlgorithm);
            KeyFactory keyFactory = KeyFactory.getInstance(keyAlgorithm);
            
            // Generate the public key
            PublicKey pubKey = keyFactory.generatePublic(spec);
            
            // Decode the signature from Base64
            byte[] signatureBytes = Base64.getDecoder().decode(signature);
            
            // Create a Signature instance based on the signing algorithm
            Signature sig = Signature.getInstance(getJavaSignatureAlgorithm(signingAlgorithm));
            
            // Initialize the signature with the public key
            sig.initVerify(pubKey);
            
            // Update the signature with the original data
            sig.update(originalData.getBytes(StandardCharsets.UTF_8));
            
            // Verify the signature
            return sig.verify(signatureBytes);
        } catch (Exception e) {
            throw new RuntimeException("Error verifying signature with public key: " + e.getMessage(), e);
        }
    }

    /**
     * Helper method to get the Java signature algorithm from KMS signing algorithm
     * @param signingAlgorithm The KMS signing algorithm
     * @return Java signature algorithm string
     */
    private String getJavaSignatureAlgorithm(String signingAlgorithm) {
        switch(signingAlgorithm) {
            case "RSASSA_PKCS1_V1_5_SHA_256":
                return "SHA256withRSA";
            case "RSASSA_PKCS1_V1_5_SHA_384":
                return "SHA384withRSA";
            case "RSASSA_PKCS1_V1_5_SHA_512":
                return "SHA512withRSA";
            case "RSASSA_PSS_SHA_256":
                return "RSASSA-PSS";
            case "RSASSA_PSS_SHA_384":
                return "RSASSA-PSS";
            case "RSASSA_PSS_SHA_512":
                return "RSASSA-PSS";
            case "ECDSA_SHA_256":
                return "SHA256withECDSA";
            case "ECDSA_SHA_384":
                return "SHA384withECDSA";
            case "ECDSA_SHA_512":
                return "SHA512withECDSA";
            default:
                return "SHA256withRSA"; // Default fallback
        }
    }

    /**
     * Helper method to get the key algorithm from signing algorithm
     * @param signingAlgorithm The signing algorithm
     * @return Key algorithm (RSA or EC)
     */
    private String getKeyAlgorithmFromSigningAlgorithm(String signingAlgorithm) {
        if (signingAlgorithm.startsWith("ECDSA")) {
            return "EC"; // Elliptic Curve
        } else {
            return "RSA"; // RSA
        }
    }

    /**
     * Helper method to get the signing algorithm spec from string
     * @param algorithmString The algorithm string
     * @return SigningAlgorithmSpec enum value
     */
    private SigningAlgorithmSpec getSigningAlgorithmSpec(String algorithmString) {
        try {
            return SigningAlgorithmSpec.fromValue(algorithmString);
        } catch (IllegalArgumentException e) {
            // If the algorithm string is invalid, default to RSASSA_PKCS1_V1_5_SHA_256
            return SigningAlgorithmSpec.RSASSA_PKCS1_V1_5_SHA_256;
        }
    }
}