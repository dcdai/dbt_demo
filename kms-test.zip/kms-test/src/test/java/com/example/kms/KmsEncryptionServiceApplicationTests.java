package com.example.kms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KmsEncryptionServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}